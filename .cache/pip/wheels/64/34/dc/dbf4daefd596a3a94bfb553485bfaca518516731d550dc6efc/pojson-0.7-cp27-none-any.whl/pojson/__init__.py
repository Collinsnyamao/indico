import sys
from pojson.convert import po2dict, convert


PY3K = sys.version_info >= (3, 0)
